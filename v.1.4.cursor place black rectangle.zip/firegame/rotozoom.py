from scaling import scalinglines, scalingpoints
from rotating import rotatepoints, rotatepoints3d
from settings import WIN_CENTER, GAMESIZE, MYBACKGR

def rotozoom2d(rows, columns, scale, myalfa):
    trows = []
    tcolumns = []
    frows = []
    fcolumns = []

    tbackgr = rotatepoints(WIN_CENTER, MYBACKGR, myalfa)
    fbackgr = scalingpoints(tbackgr, scale, WIN_CENTER)
    
    trows = scalinglines(rows,scale, WIN_CENTER)
    tcolumns = scalinglines(columns,scale, WIN_CENTER)
    for i in range(GAMESIZE+1):     
        frows.append(rotatepoints(WIN_CENTER, trows[i],    myalfa))
        fcolumns.append(rotatepoints(WIN_CENTER, tcolumns[i], myalfa))
    return frows, fcolumns, fbackgr 

def rotozoom3d(rows, columns, scale, alfa2d, beta3d):
    trows = []
    tcolumns = []

    frows = []
    fcolumns = []
    
    rows3d = []
    columns3d = []
    
    fbackgr  = scalingpoints(MYBACKGR, scale, WIN_CENTER)
    tbackgr  = rotatepoints(WIN_CENTER, fbackgr, alfa2d)
    backgr3d = rotatepoints3d(WIN_CENTER, tbackgr, beta3d)
    
    trows = scalinglines(rows,scale, WIN_CENTER)
    tcolumns = scalinglines(columns,scale, WIN_CENTER)

    for i in range(GAMESIZE+1):     
        frows.append(rotatepoints(WIN_CENTER, trows[i],    alfa2d))
        fcolumns.append(rotatepoints(WIN_CENTER, tcolumns[i], alfa2d))

    for i in range(GAMESIZE+1):     
        rows3d.append(rotatepoints3d(WIN_CENTER, frows[i],    beta3d))
        columns3d.append(rotatepoints3d(WIN_CENTER, fcolumns[i], beta3d))
    return rows3d, columns3d, backgr3d 

def rotozoom3d1(obj, scale, alfa2d, beta3d):
    
    fobj  = scalingpoints(obj, scale, WIN_CENTER)
    tobj  = rotatepoints(WIN_CENTER, fobj, alfa2d)
    obj3d = rotatepoints3d(WIN_CENTER, tobj, beta3d)
    return  obj3d 

def rotocusor3d1(curs, alfa2d):
    tcurs  = rotatepoints(  WIN_CENTER, curs, -alfa2d)
    return  tcurs       

def rotoY(rows, columns, beta3d):
    trows = []
    tcolumns = []

    for i in range(GAMESIZE+1):     
        trows.append(rotatepoints3d(WIN_CENTER, rows[i],    beta3d))
        tcolumns.append(rotatepoints3d(WIN_CENTER, columns[i], beta3d))

    return trows, tcolumns





