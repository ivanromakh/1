import random 
import pygame
from   pygame.locals import *
import sys
from time import sleep

import player
from player import* 
from settings import *
from menu import Menu, mennu
from scaling import scalinglines, scalingpoints
from rotating import rotatepoints
from drawsgame import drawlines
from rotozoom import rotozoom2d, rotozoom3d
from borders import borders

# !! NOT VERY GOOD !!
#find squere of enemy on the map 
def findsquere(encord):
    xmin = encord[0][0]
    xmax = encord[0][0]
    ymin = encord[0][1]
    ymax = encord[0][1]
    for i in range(3):
        if xmin > encord[i][0]:
            xmin = encord[i][0]
        if xmax < encord[i][0]:
            xmax = encord[i][0]
        if ymin > encord[i][1]:
            ymin = encord[i][1]
        if ymax < encord[i][1]:
            ymax = encord[i][1]
    return (xmin, xmax, ymin, ymax)


def drawscbull(screen, (x, y), scale):
    pygame.draw.circle(screen, (250,0,250), (x, y), int(BUL_SIZE*scale) , int(BUL_SIZE*scale))

def move(p, x, y):
    p[0][0] = p[0][0] - x
    p[0][1] = p[0][1] - y
    p[1][0] = p[1][0] - x
    p[1][1] = p[1][1] - y 
    p[2][0] = p[2][0] - x
    p[2][1] = p[2][1] - y
    return p


    
def drawpoligon(screen, pos):
    pygame.draw.polygon(screen, PL_COLOR, ((pos[0] - ZOOM/2, pos[1]),
                                           (pos[0] + ZOOM/2, pos[1] - ZOOM/2),
                                           (pos[0] + ZOOM/2, pos[1] + ZOOM/2)))

def drawrect(screen, pos):
    pygame.draw.polygon(screen, PL_COLOR, ((pos[0] - ZOOM/2, pos[1] - ZOOM/2),
                                           (pos[0] - ZOOM/2, pos[1] + ZOOM/2),
                                           (pos[0] + ZOOM/2, pos[1] + ZOOM/2),
                                           (pos[0] + ZOOM/2, pos[1] - ZOOM/2)))

# draw information and fps  
def drawtext(screen, timer):
    mytext = pygame.font.SysFont("monospace", 15)
    timer.tick(40)
    text = mytext.render("FPS "+str(timer.get_fps()), 1, (10, 10, 10))
    screen.blit(text, (5, 160))

#zooming recived players objects
def enzooming(obj, center, x, y, scale):
    dis = mypoints(obj, center, x, y, scale)
    return dis

#zooming bullet
def bzooming(obj, center, x, y, scale):
    dis = mypoint(obj, center, x, y, scale)
    return dis

#shift points by player moving and zooming
def mypoints(points, center, x, y, scale):
    newp = []
    for p in points: 
        newp.append((int(center[0]+((p[0]-center[0])*scale)), int(center[1]+((p[1]-center[1])*scale))))
    return newp

#shift point by player moving and zooming
def mypoint(p, center, x, y, scale):
    return (int(center[0]+((p[0]-center[0]-x)*scale)), int(center[1]+((p[1]-center[1]-y)*scale)))
    
# main function
def main():
    pygame.init()
    # menu check server or client
    mennu()
    screen = pygame.display.set_mode(DISPLAY) 
    timer = pygame.time.Clock()

    # get player start position
    myplayer = player.Player(WIN_WIDTH/2-ZOOM/2,
                             WIN_HEIGHT/2-ZOOM/2,
                             True, False, CANNON)
    player_bul = []
    
    # zoom press
    iszoomincres  = False
    iszoomdecres  = False
    isrotaterigth = False
    isrotateleft  = False
    isrotateup  = False
    isrotatedown  = False
    
    

    grows, gcolumns = borders()

    
    # scaling and rotating (for draw)
    frows = []
    fcolumns = []
    fbackgr = MYBACKGR
    for i in range(GAMESIZE+1): 
        frows.append(grows[i])
        fcolumns.append(gcolumns[i])
        
    #start angle2d, angle3d and scale
    myalfa2d = 0
    myalfa3d = 0
    scale = 1
    zoom = ZOOM + 0.0

    pos = WIN_CENTER

    #loop
    while True:
        #draw background on the screen 
        screen.fill(BACKGROUND_COLOR)

        #draw game map        
        pygame.draw.polygon(screen, (255,255,255), fbackgr)
        drawlines(screen,fcolumns,frows)

        # zooming
        if iszoomincres   == True:
            if scale<MAXSCALE:
                zoom += 2
                scale = zoom/ZOOM
                (frows,fcolumns, fbackgr) = rotozoom2d(grows, gcolumns, scale, myalfa2d)
        elif iszoomdecres == True:
            if scale>MINSCALE:
                zoom -= 2
                scale = zoom/ZOOM
                (frows,fcolumns, fbackgr) = rotozoom2d(grows, gcolumns, scale, myalfa2d)

        #map rotating
        if isrotaterigth  == True:
            myalfa2d+=0.5
            (frows,fcolumns, fbackgr) = rotozoom2d(grows, gcolumns, scale, myalfa2d)
        elif isrotateleft == True:
            myalfa2d-=0.5
            (frows,fcolumns, fbackgr) = rotozoom2d(grows, gcolumns, scale, myalfa2d)
        if isrotateup   == True:
            myalfa3d-=0.5
            (frows,fcolumns, fbackgr) = rotozoom2d(grows, gcolumns, scale, myalfa2d)
        if isrotatedown == True:
            myalfa3d-=0.5
            (frows,fcolumns, fbackgr) = rotozoom2d(grows, gcolumns, scale, myalfa2d)

        #draw and update thisplayer object 
        pos = mouse.get_pos()
        myplayer.update(0, 1, myplayer)
        myplayer.draw(screen, pos, scale)
        
        # ALL EVENTS for gamemode
        for e in pygame.event.get():
            # check multipress 
            keystate = pygame.key.get_pressed()
        
            # exit
            if e.type == QUIT:
                pygame.quit()
                sys.exit()
 
            # start moving and rotating
            elif e.type == KEYDOWN:
                if keystate[K_ESCAPE]:
                    pygame.quit()
                    sys.exit()
                if keystate[K_UP]:
                    isrotateup = False
                if keystate[K_DOWN]:
                    isrotatedown = False
                if keystate[K_LEFT]:
                    isrotateleft = True
                if keystate[K_RIGHT]:
                    isrotaterigth = True
                if keystate[K_1]:
                    iszoomincres = True
                if keystate[K_2]:
                    iszoomdecres = True

            # stop moving and rotating        
            elif e.type == KEYUP:
                if e.key == K_UP:
                    isrotateup = False
                if e.key == K_DOWN:
                    isrotatedown = False
                if e.key == K_LEFT:
                    isrotateleft = False
                if e.key == K_RIGHT:
                    isrotaterigth = False
                if e.key == K_1:
                    iszoomincres = False
                if e.key == K_2:
                    iszoomdecres = False

            #player shoot        
            elif e.type == pygame.MOUSEBUTTONDOWN:
                # get mouse position        
                pos = pygame.mouse.get_pos()
                    
                player_bul.append(myplayer.shoot(pos))
        
        drawtext(screen, timer)
        pygame.display.flip()

# main fuction                
if __name__ == "__main__":
    main()
    
