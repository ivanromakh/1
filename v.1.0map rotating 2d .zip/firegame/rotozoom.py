from scaling import scalinglines, scalingpoints
from rotating import rotatepoints, rotatepoints3d
from settings import WIN_CENTER, GAMESIZE, MYBACKGR
XXX = 10

def rotozoom2d(rows, columns, scale, myalfa):
    trows = []
    tcolumns = []
    frows = []
    fcolumns = []

    tbackgr = rotatepoints(WIN_CENTER, MYBACKGR, myalfa)
    fbackgr = scalingpoints(tbackgr, scale, WIN_CENTER)
    
    trows = scalinglines(rows,scale, WIN_CENTER)
    tcolumns = scalinglines(columns,scale, WIN_CENTER)
    for i in range(GAMESIZE+1):     
        frows.append(rotatepoints(WIN_CENTER, trows[i],    myalfa))
        fcolumns.append(rotatepoints(WIN_CENTER, tcolumns[i], myalfa))
    return frows, fcolumns, fbackgr 

def rotozoom3d(rows, columns, scale, myalfa):
    trows = []
    tcolumns = []
    frows = []
    fcolumns = []

    tbackgr = rotatepoints(WIN_CENTER, MYBACKGR, myalfa)
    fbackgr = scalingpoints(tbackgr, scale, WIN_CENTER)
    
    trows = scalinglines(rows,scale, WIN_CENTER)
    tcolumns = scalinglines(columns,scale, WIN_CENTER)

    for i in range(GAMESIZE+1):     
        frows.append(rotatepoints3d(WIN_CENTER, trows[i],    myalfa))
        fcolumns.append(rotatepoints3d(WIN_CENTER, tcolumns[i], myalfa))
        
    for i in range(GAMESIZE+1):     
        frows.append(rotatepoints(WIN_CENTER, trows[i],    myalfa))
        fcolumns.append(rotatepoints(WIN_CENTER, tcolumns[i], myalfa))
    return frows, fcolumns, fbackgr 

    
