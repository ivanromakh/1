import pygame

from settings import GAMESIZE

def drawlines(screen,line1,line2):
    for i in range(GAMESIZE+1):
        pygame.draw.line(screen, (255,0,0), line1[i][0],line1[i][1])
        pygame.draw.line(screen, (255,0,0), line2[i][0], line2[i][1])
