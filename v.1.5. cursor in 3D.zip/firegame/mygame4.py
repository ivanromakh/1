import random 
import pygame
from   pygame.locals import *
import sys
from time import sleep

from settings import *
from menu import Menu, mennu
from scaling import scalinglines, scalingpoints
from rotating import rotatepoints
from drawsgame import drawlines
from rotozoom import rotozoom3d, rotozoom3d1, rotocusor3d1, rotoY, rotoX
from borders import borders


# draw information and fps  
def drawtext(screen, timer):
    mytext = pygame.font.SysFont("monospace", 15)
    timer.tick(40)
    text = mytext.render("FPS "+str(timer.get_fps()), 1, (10, 10, 10))
    screen.blit(text, (5, 160))

    
# main function
def main():
    pygame.init()
    # menu check server or client
    mennu()
    screen = pygame.display.set_mode(DISPLAY) 
    timer = pygame.time.Clock()

    # klavisha press
    iszoomincres  = False
    iszoomdecres  = False
    isrotaterigth = False
    isrotateleft  = False
    isrotateup    = False
    isrotatedown  = False
    
    objects = []
    fobjects = []
    grows, gcolumns = borders()
    # scaling and rotating (for draw)
    frows = []
    fcolumns = []
    trows = []
    tcolumns = []

    fbackgr = MYBACKGR
    for i in range(GAMESIZE+1): 
        frows.append(grows[i])
        fcolumns.append(gcolumns[i])
        trows.append(grows[i])
        tcolumns.append(gcolumns[i])
    #start angle2d, angle3d and scale
    myalfa2d = 0
    mybeta3d = 0
    scale = 1
    zoom = ZOOM + 0.0
      
    pos = WIN_CENTER
    #loop
    while True:
                #DRAW
        #draw background on the screen 
        screen.fill(BACKGROUND_COLOR)
        #draw game map        
        pygame.draw.polygon(screen, (255,255,255), fbackgr)
        drawlines(screen,fcolumns,frows)

        for obj in fobjects:
            pygame.draw.polygon(screen, (0,0,0), obj)
        
        # zooming
        if iszoomincres   == True:
            if scale<MAXSCALE:
                zoom += 2
                scale = zoom/ZOOM
                (frows,fcolumns, fbackgr) = rotozoom3d(grows, gcolumns, scale,
                                                       myalfa2d, mybeta3d)
                fobjects = []
                for obj in objects:
                    fobjects.append(rotozoom3d1(obj, scale,myalfa2d, mybeta3d))
        elif iszoomdecres == True:
            if scale>MINSCALE:
                zoom -= 2
                scale = zoom/ZOOM
                (frows,fcolumns, fbackgr) = rotozoom3d(grows, gcolumns, scale,
                                                       myalfa2d, mybeta3d)
                fobjects = []
                for obj in objects:
                    fobjects.append(rotozoom3d1(obj, scale,myalfa2d, mybeta3d))
        #map rotating
        if isrotaterigth  == True:
            myalfa2d+=1
            (frows,fcolumns, fbackgr) = rotozoom3d(grows, gcolumns, scale,
                                                       myalfa2d, mybeta3d)
            fobjects = []
            for obj in objects:
                    fobjects.append(rotozoom3d1(obj, scale,myalfa2d, mybeta3d))

        elif isrotateleft == True:
            myalfa2d-=1
            (frows,fcolumns, fbackgr) = rotozoom3d(grows, gcolumns, scale,
                                                       myalfa2d, mybeta3d)
            fobjects = []
            for obj in objects:
                    fobjects.append(rotozoom3d1(obj, scale,myalfa2d, mybeta3d))
        if isrotateup   == True:
            if mybeta3d > -80:
                mybeta3d-=1
                (frows,fcolumns, fbackgr) = rotozoom3d(grows, gcolumns, scale,
                                                       myalfa2d, mybeta3d)
                fobjects = []
                for obj in objects:
                    fobjects.append(rotozoom3d1(obj, scale,myalfa2d, mybeta3d))
        if isrotatedown == True:
            if mybeta3d < 0:
                mybeta3d+=1
                (frows,fcolumns, fbackgr) = rotozoom3d(grows, gcolumns, scale,
                                                       myalfa2d, mybeta3d)
                fobjects = []
                for obj in objects:
                    fobjects.append(rotozoom3d1(obj, scale,myalfa2d, mybeta3d))
        
        pos = pygame.mouse.get_pos()
        temp = rotocusor3d1([pos], myalfa2d, mybeta3d)
        pos = [0,0]
        pos[0] = temp[0][0]
        pos[1] = temp[0][1]
        pygame.draw.polygon(screen, (0,0,200), ((pos[0],pos[1]),(pos[0]+5,pos[1]),(pos[0],pos[1]+5)))
                            
        # ALL EVENTS for gamemode
        for e in pygame.event.get():
            # check multipress 
            keystate = pygame.key.get_pressed()
        
            # exit
            if e.type == QUIT:
                pygame.quit()
                sys.exit()
 
            # start moving and rotating
            elif e.type == KEYDOWN:
                if keystate[K_ESCAPE]:
                    pygame.quit()
                    sys.exit()
                if keystate[K_UP]:
                    isrotateup = True
                if keystate[K_DOWN]:
                    isrotatedown = True
                if keystate[K_LEFT]:
                    isrotateleft = True
                if keystate[K_RIGHT]:
                    isrotaterigth = True
                if keystate[K_1]:
                    iszoomincres = True
                if keystate[K_2]:
                    iszoomdecres = True

            # stop moving and rotating        
            elif e.type == KEYUP:
                if e.key == K_UP:
                    isrotateup = False
                if e.key == K_DOWN:
                    isrotatedown = False
                if e.key == K_LEFT:
                    isrotateleft = False
                if e.key == K_RIGHT:
                    isrotaterigth = False
                if e.key == K_1:
                    iszoomincres = False
                if e.key == K_2:
                    iszoomdecres = False
                
            elif e.type == pygame.MOUSEBUTTONDOWN:        

                #pos = [0,0]
                #pos[0] = temp[0][0]
                #pos[1] = temp[0][1]
                #bad work
                #(trows, tcolumns) = rotoY(grows, gcolumns, mybeta3d)
                (trows, tcolumns) = rotoX(grows, gcolumns, mybeta3d)
                
                for i in range(len(tcolumns)-1):
                    if pos[0]>= tcolumns[i][0][0]:
                        if pos[0] < tcolumns[i+1][0][0]:
                            for j in range(len(trows)-1):
                                if pos[1] >= trows[j][0][1]:
                                    if pos[1] < trows[j+1][0][1]:
                                        isheres = False  
                                        for obj in objects:
                                            if grows[j][0][1] ==  obj[0][0] and gcolumns[i][0][0] == obj[0][1]: 
                                               isheres = True
                                               print isheres
                                        if isheres == False:
                                            obj = ((gcolumns[i][0][0], grows[j][0][1]),
                                                   (gcolumns[i][0][0], grows[j+1][0][1]),
                                                   (gcolumns[i+1][0][0], grows[j+1][0][1]),
                                                   (gcolumns[i+1][0][0], grows[j][0][1]))
                                            objects.append(obj)
                                            fobjects.append(rotozoom3d1(obj, scale,myalfa2d, mybeta3d))
                                        break
                            break
                
        drawlines(screen,tcolumns,trows)
        drawtext(screen, timer)
        pygame.display.flip()

# main fuction                
if __name__ == "__main__":
    main()
    
