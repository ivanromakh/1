import pygame
from rotozoom import rotozoom3d1, rotocusor3d1, rotoX

def cursor(scale, myalfa2d, mybeta3d, gcolumns, grows, objects, fobjects):
  
  pos = pygame.mouse.get_pos()
  temp = rotocusor3d1([pos], myalfa2d, mybeta3d)
  pos = [0,0]
  pos[0] = temp[0][0]
  pos[1] = temp[0][1]    
                
  (trows, tcolumns) = rotoX(scale, grows, gcolumns, mybeta3d)
  for i in range(len(tcolumns)-1):
      if pos[0]>= tcolumns[i][0][0]:
          if pos[0] < tcolumns[i+1][0][0]:
              for j in range(len(trows)-1):
                  if pos[1] >= trows[j][0][1]:
                      if pos[1] < trows[j+1][0][1]:
                          isheres = False 
                          for obj in objects:
                              if grows[j][0][1] ==  obj[0][0] and gcolumns[i][0][0] == obj[0][1]: 
                                  isheres = True
                          if isheres == False:
                              obj = ((gcolumns[i][0][0], grows[j][0][1]),
                                     (gcolumns[i][0][0], grows[j+1][0][1]),
                                     (gcolumns[i+1][0][0], grows[j+1][0][1]),
                                     (gcolumns[i+1][0][0], grows[j][0][1]))
                              objects.append(obj)
                              fobjects.append(rotozoom3d1(obj, scale,myalfa2d, mybeta3d))
                              break
  return  fobjects                                  