import random
import numpy as np

from settings import GAMESIZE, YELLOW, RED, BLUE, GREEN, INT

def mapgen(screen, grows, gcolumns):
	mymap = np.array([],INT)
	
	for i in range(GAMESIZE):
		for j in range(GAMESIZE):
			pl = random.randint(0,3)
			if pl == 0:
				mymap = np.append(mymap, (GREEN,((gcolumns[j][0][0], grows[i][0][1]),
			  		       (gcolumns[j+1][0][0], grows[i][0][1]),
						   (gcolumns[j+1][0][0], grows[i+1][0][1]),
						   (gcolumns[j][0][0],   grows[i+1][0][1]))))
			if pl == 1:
				mymap = np.append(mymap, (YELLOW,((gcolumns[j][0][0], grows[i][0][1]),
			  		       (gcolumns[j+1][0][0], grows[i][0][1]),
						   (gcolumns[j+1][0][0], grows[i+1][0][1]),
						   (gcolumns[j][0][0],   grows[i+1][0][1]))))
			if pl == 2:
				mymap = np.append(mymap, (BLUE,((gcolumns[j][0][0], grows[i][0][1]),
			  		       (gcolumns[j+1][0][0], grows[i][0][1]),
						   (gcolumns[j+1][0][0], grows[i+1][0][1]),
						   (gcolumns[j][0][0],   grows[i+1][0][1]))))
			if pl == 3:
				mymap = np.append(mymap, (RED,((gcolumns[j][0][0], grows[i][0][1]),
			  		       (gcolumns[j+1][0][0], grows[i][0][1]),
						   (gcolumns[j+1][0][0], grows[i+1][0][1]),
						   (gcolumns[j][0][0],   grows[i+1][0][1]))))
	mymap = mymap.reshape((GAMESIZE*GAMESIZE,2))
	return mymap	
