import numpy as np


from settings import GAMESIZE, REZSIZE2, WIN_CENTER, ZOOM


def borders():
    
    # game colomns
    bordx1  = WIN_CENTER[0] - REZSIZE2
    bordx2 = WIN_CENTER[0] + REZSIZE2
    bordy1 = WIN_CENTER[1] - REZSIZE2
    bordy2 = WIN_CENTER[1] + REZSIZE2
    #index where insert
    count = np.arange(1,GAMESIZE+2,1)
    count1 = np.arange(1,(GAMESIZE+1)*2,2)
    count2 = np.arange(3,(GAMESIZE+2)*3,3)
    #generate masive columns
    gcol = np.arange(bordx1, bordx2+ZOOM, ZOOM) 
    gcolum = np.insert(gcol, count, gcol) 
    gcolum = np.insert(gcolum, count1, bordy1)
    gcolum = np.insert(gcolum, count2, bordy2)
    gcolumns = gcolum.reshape((GAMESIZE+1),2,2) 
    
    #rows
    bordy = WIN_CENTER[1] - REZSIZE2
    bordy2 = WIN_CENTER[1] + REZSIZE2
    bordx1 = WIN_CENTER[0] - REZSIZE2
    bordx2 = WIN_CENTER[0] + REZSIZE2
    #index where insert
    count = np.arange(0,GAMESIZE+1,1)
    count1 = np.arange(0,(GAMESIZE+1)*2,2)
    count2 = np.arange(2,(GAMESIZE+1)*3,3)
    #generate masive rows
    grow = np.arange(bordy, bordy2+ZOOM, ZOOM) 
    grows = np.insert(grow, count, grow) 
    grows = np.insert(grows, count1, bordx1)
    grows = np.insert(grows, count2, bordx2)
    grows = grows.reshape((GAMESIZE+1),2,2)

    return grows, gcolumns
