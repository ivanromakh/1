from scaling import scalinglines, scalingpoints
from rotating import rotatepoints, rotatepoints3d
from settings import WIN_CENTER, GAMESIZE, MYBACKGR
XXX = 10

def rotozoom2d(rows, columns, scale, myalfa):
    trows = []
    tcolumns = []
    frows = []
    fcolumns = []

    tbackgr = rotatepoints(WIN_CENTER, MYBACKGR, myalfa)
    fbackgr = scalingpoints(tbackgr, scale, WIN_CENTER)
    
    trows = scalinglines(rows,scale, WIN_CENTER)
    tcolumns = scalinglines(columns,scale, WIN_CENTER)
    for i in range(GAMESIZE+1):     
        frows.append(rotatepoints(WIN_CENTER, trows[i],    myalfa))
        fcolumns.append(rotatepoints(WIN_CENTER, tcolumns[i], myalfa))
    return frows, fcolumns, fbackgr 

def rotozoom3d(rows, columns, scale, alfa2d, beta3d):
    trows = []
    tcolumns = []

    frows = []
    fcolumns = []
    
    rows3d = []
    columns3d = []

    

    
    fbackgr  = scalingpoints(MYBACKGR, scale, WIN_CENTER)
    tbackgr  = rotatepoints(WIN_CENTER, fbackgr, alfa2d)
    backgr3d = rotatepoints3d(WIN_CENTER, tbackgr, beta3d)
    
    trows = scalinglines(rows,scale, WIN_CENTER)
    tcolumns = scalinglines(columns,scale, WIN_CENTER)

    for i in range(GAMESIZE+1):     
        frows.append(rotatepoints(WIN_CENTER, trows[i],    alfa2d))
        fcolumns.append(rotatepoints(WIN_CENTER, tcolumns[i], alfa2d))

    for i in range(GAMESIZE+1):     
        rows3d.append(rotatepoints3d(WIN_CENTER, frows[i],    beta3d))
        columns3d.append(rotatepoints3d(WIN_CENTER, fcolumns[i], beta3d))
    return rows3d, columns3d, backgr3d 

    
